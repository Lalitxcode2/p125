function setup(){
    video = createCapture(VIDEO);
    video.size(550,600);

    canvas = createCanvas(550,500);
    canvas.position(650,120);

    posenet = ml5.poseNet(video,modelLoaded);
     posenet.on("pose",gotPoses);

} 

function modelLoaded(){
    console.log("Model Loaded");
}

function gotPoses(results){
    if(results.length > 0)
    {
        console.log(results);

        leftwristx = results[0].pose.leftWrist.x;
        rightwristx = results[0].pose.rightWrist.x;
        difference = floor(leftwristx-rightwristx);
    }
}
function draw(){
    background('darkslategrey');

    textSize(difference);
    fill('white');
    text( 'Lalit' , 50, 400);
}